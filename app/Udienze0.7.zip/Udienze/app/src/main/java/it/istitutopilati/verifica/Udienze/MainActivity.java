package it.istitutopilati.verifica.Udienze;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Intent;
import android.net.Uri;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.internal.GoogleSignInOptionsExtensionParcelable;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;

import it.istitutopilati.verifica.test.R;


public class MainActivity extends AppCompatActivity {

    Button button;
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    FirebaseUser user;
    String docenteAttuale;
    String data = "";

    @Override
    protected void onStart(){
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        button = (Button) findViewById(R.id.btnLogOut);
        mAuth = FirebaseAuth.getInstance();

        if(FirebaseAuth.getInstance().getCurrentUser()!=null) {
        user = FirebaseAuth.getInstance().getCurrentUser();
        docenteAttuale = user.getDisplayName();
       }



        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser()== null){
                    startActivity(new Intent(MainActivity.this, LauncherActivity.class));
                }
            }

        };

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
            }
        });

        ListView l1 = findViewById(R.id.lv1);   
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayAdapter arrayAdapter = new CustomArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        l1.setAdapter(arrayAdapter);



        String docente = null;
        String orario = null;


        try {

            JSONObject obj = new JSONObject(loadJSONFromAsset());
            JSONArray m_jArry = obj.getJSONArray("udienze");

            for (int i = 0; i < m_jArry.length(); i++) {
                JSONObject jo_inside = m_jArry.getJSONObject(i);

                String studente = jo_inside.getString("studente");
                String classe = jo_inside.getString("classe");

                JSONArray array1 = jo_inside.getJSONArray("prenotazioni");
                for(int j = 0; j < array1.length(); j++){
                    JSONObject oggetto = new JSONObject(array1.getString(j));
                    docente = oggetto.getString("docente");
                    orario = oggetto.getString("orario");
                    if(docenteAttuale!=null) {
                        if (docenteAttuale.equals(docente)) {
                            arrayList.add("\nOrario udienza: " + orario + "\n\nStudente: " + studente + "\n\nClasse: " + classe + "\n");
                        }
                    }
                }
            }
        }catch (JSONException e) {
            e.printStackTrace();
        }


    }





    private String loadJSONFromAsset() {
        String json = "";
        try {
            URL url = new URL("https://www.vallidelnoce.it/udienze_pilati/udienze.json");
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while (line!=null){
                line = bufferedReader.readLine();
                json = json+ line;
            }
        } catch (MalformedURLException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
        return json;
    }


}
