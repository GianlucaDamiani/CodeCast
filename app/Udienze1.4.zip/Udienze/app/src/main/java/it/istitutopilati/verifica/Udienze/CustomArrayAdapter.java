package it.istitutopilati.verifica.Udienze;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.List;

public class CustomArrayAdapter<T> extends ArrayAdapter {
    public CustomArrayAdapter(Context context, int resource) {
        super(context, resource);
    }

    public CustomArrayAdapter(Context context, int resource, int textViewResourceId) {
        super(context, resource, textViewResourceId);
    }

    public CustomArrayAdapter(Context context, int resource, Object[] objects) {
        super(context, resource, objects);
    }

    public CustomArrayAdapter(Context context, int resource, int textViewResourceId, Object[] objects) {
        super(context, resource, textViewResourceId, objects);
    }

    public CustomArrayAdapter(Context context, int resource, List objects) {
        super(context, resource, objects);
    }

    public CustomArrayAdapter(Context context, int resource, int textViewResourceId, List objects) {
        super(context, resource, textViewResourceId, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);

        if (position % 2 == 1) {
            view.setBackgroundColor(Color.parseColor("#E3E1DB"));
        }else {
            view.setBackgroundColor(Color.WHITE);
        }

        return view;
    }
}
