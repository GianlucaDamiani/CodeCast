package it.istitutopilati.verifica.Udienze;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import it.istitutopilati.verifica.test.R;


public class MainActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView l1 = findViewById(R.id.lv1);
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);
        l1.setAdapter(arrayAdapter);


        String docenteAttuale = "Odorizzi Lara";
        String docente = null;
        String orario = null;


        try {
            JSONObject obj = new JSONObject(loadJSONFromAsset());
            JSONArray m_jArry = obj.getJSONArray("udienze");

            for (int i = 0; i < m_jArry.length(); i++) {
                JSONObject jo_inside = m_jArry.getJSONObject(i);

                String studente = jo_inside.getString("studente");
                String classe = jo_inside.getString("classe");

                JSONArray array1 = jo_inside.getJSONArray("prenotazioni");
                for(int j = 0; j < array1.length(); j++){
                    JSONObject oggetto = new JSONObject(array1.getString(j));
                    docente = oggetto.getString("docente");
                    orario = oggetto.getString("orario");
                    if(docenteAttuale.equals(docente)){
                        boolean ctrl = true;
                        arrayList.add("\nOrario udienza: "+orario+"\n\nStudente: "+studente+"\n\nClasse: "+classe+"\n");
                    }
                }
            }
        }catch (JSONException e) {
            e.printStackTrace();
        }


    }

    private String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = getApplication().getAssets().open("udienze.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


}
