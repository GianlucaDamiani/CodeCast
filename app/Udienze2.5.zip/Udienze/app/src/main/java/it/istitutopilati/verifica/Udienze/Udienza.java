package it.istitutopilati.verifica.Udienze;

class Udienza {
    String studente;
    String classe;
    String orario;

    public Udienza(String studente, String classe, String orario){
        this.studente=studente;
        this.classe=classe;
        this.orario=orario;
    }
    public String getStudente(){
        return this.studente;
    }
    public String getClasse(){
        return this.classe;
    }
    public String getOrario(){
        return this.orario;
    }

}
