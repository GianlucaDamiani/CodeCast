package it.istitutopilati.verifica.Udienze;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Handler;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

import it.istitutopilati.verifica.test.R;


public class MainActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    FirebaseUser user;
    String docenteAttuale="";
    String controlloEmail="";
    String docente = "";
    String orario = "";

    @Override
    protected void onStart(){
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Button button = (Button) findViewById(R.id.btnLogOut1);
        Button button2 = (Button) findViewById(R.id.btnLogOut2);
        TextView tvDoc = (TextView) findViewById(R.id.tvDocente);
        TextView tv1 = (TextView) findViewById(R.id.tv1);
        final SwipeRefreshLayout swipeRefresh = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        final TextView tvConnection = (TextView) findViewById(R.id.tvConnection);
        mAuth = FirebaseAuth.getInstance();



        if(FirebaseAuth.getInstance().getCurrentUser()!=null) {
            user = FirebaseAuth.getInstance().getCurrentUser();
            tv1.setText("Accesso effettuato come: \n");
            controlloEmail = user.getEmail();
            tvDoc.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
            String tmp = user.getDisplayName().toLowerCase();
            String[] parts = tmp.split("\\s+");
            Arrays.sort(parts);
            StringBuilder sb = new StringBuilder();
            for(String s:parts){
                sb.append(s);
                sb.append(" ");
            }
            docenteAttuale = sb.toString().trim();
            Log.w("Datigoogle", docenteAttuale);

        }

        if (!isOnline()) {
            tvConnection.setBackgroundColor(Color.parseColor("#F44336"));
            tvConnection.setText("Le udienze potrebbero non essere aggiornate");
        } else {
            tvConnection.setBackgroundColor(Color.parseColor("#5AB963"));
            tvConnection.setText("Le udienze sono aggiornate");
        }


        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser()== null){
                    startActivity(new Intent(MainActivity.this, LauncherActivity.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                }
            }

        };

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefresh.setRefreshing(true);
                (new Handler()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        swipeRefresh.setRefreshing(false);
                        if (!isOnline()) {
                            tvConnection.setBackgroundColor(Color.parseColor("#F44336"));
                            tvConnection.setText("Le udienze potrebbero non essere aggiornate");
                            Toast.makeText(MainActivity.this,"Impossibile aggiornare\nVerificare connessione ad internet", Toast.LENGTH_LONG).show();
                        } else {
                            tvConnection.setBackgroundColor(Color.parseColor("#5AB963"));
                            tvConnection.setText("Le udienze sono aggiornate");
                            finish();
                            overridePendingTransition(0, 0);
                            startActivity(getIntent().addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                        }
                    }
                },1500);

            }
        });

       button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                if (Build.VERSION_CODES.KITKAT <= Build.VERSION.SDK_INT) {
                    ((ActivityManager)getApplicationContext().getSystemService(ACTIVITY_SERVICE))
                            .clearApplicationUserData(); // note: it has a return value!
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });




        ListView l1 = findViewById(R.id.lv1);   
        ArrayList<String> arrayList = new ArrayList<>();
        ArrayAdapter arrayAdapter = new CustomArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        l1.setAdapter(arrayAdapter);


        try {

            JSONObject obj = new JSONObject(loadJSONFromURL());
            JSONArray m_jArry = obj.getJSONArray("udienze");


            int numUdienze=0;
            Vector udienze = new Vector();
            //PER OGNI UDIENZA
            for (int i = 0; i < m_jArry.length(); i++) {
                JSONObject jo_inside = m_jArry.getJSONObject(i);

                String studente = jo_inside.getString("studente");
                String classe = jo_inside.getString("classe");

                JSONArray array1 = jo_inside.getJSONArray("prenotazioni");



                for(int j = 0; j < array1.length(); j++){
                    JSONObject oggetto = new JSONObject(array1.getString(j));
                    String tmp2 = oggetto.getString("docente").toLowerCase();
                    String[] parts = tmp2.split("\\s+");
                    Arrays.sort(parts);
                    StringBuilder sb = new StringBuilder();
                    for(String s:parts){
                        sb.append(s);
                        sb.append(" ");
                    }

                    docente = sb.toString().trim();
                    Log.w("datijson",docente);
                    orario = oggetto.getString("orario");



                    //aggiungo al vettore
                    

                    if(docenteAttuale!=null) {
                        if (docente.equals(docenteAttuale)) {
                            udienze.add(new Udienza(studente,classe,orario));
                        }
                    }

                }
            }//END for PER OGNI UDIENZA


            //ordiniamo
            for(int i = 0;i<udienze.size();i++){

                for(int j=0;j<udienze.size();j++){

                    String arrayi[] = ((Udienza)udienze.get(i)).getOrario().split(":");
                    String arrayj[] = ((Udienza)udienze.get(j)).getOrario().split(":");

                    int orai=Integer.parseInt(arrayi[0]);
                    int oraj=Integer.parseInt(arrayj[0]);

                    int mini=Integer.parseInt(arrayi[1]);
                    int minj=Integer.parseInt(arrayj[1]);

                    if(orai == oraj){
                        if(mini < minj){
                            //scambia
                            Udienza tmp= (Udienza) udienze.get(i);
                            udienze.set(i,(Udienza) udienze.get(j));
                            udienze.set(j,tmp);

                        }
                    }
                    else{
                        if(orai < oraj){
                            //scambia

                            Udienza tmp= (Udienza) udienze.get(i);
                            udienze.set(i,(Udienza) udienze.get(j));
                            udienze.set(j,tmp);
                        }
                    }



                }
            }
            for(int i = 0;i<udienze.size();i++) {
                arrayList.add("\nOrario udienza: " + ((Udienza) udienze.get(i)).getOrario() + "\n\nStudente: " + ((Udienza) udienze.get(i)).getStudente() + "\n\nClasse: " + ((Udienza) udienze.get(i)).getClasse() + "\n");
            }
            if(arrayList.size()==0){
                arrayList.add("Nessuna udienza trovata per oggi");
            }

        }catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)  {
        if (keyCode == KeyEvent.KEYCODE_BACK ) {
            finishAffinity();
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }


    private String loadJSONFromURL(){
        String json = "";
        try {
            URL url = new URL("https://www.vallidelnoce.it/udienze_pilati/udienze.json");
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while (line!=null){
                line = bufferedReader.readLine();
                json = json+ line;
            }
        } catch (MalformedURLException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
        return json;
    }


    public static class ConnectivityHelper {
        public static boolean isConnectedToNetwork(Context context) {
            ConnectivityManager connectivityManager =
                    (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

            boolean isConnected = false;
            if (connectivityManager != null) {
                NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
                isConnected = (activeNetwork != null) && (activeNetwork.isConnectedOrConnecting());
            }

            return isConnected;
        }
    }

    public boolean isOnline() {
        try {
            int timeoutMs = 1500;
            Socket sock = new Socket();
            SocketAddress sockaddr = new InetSocketAddress("8.8.8.8", 53);

            sock.connect(sockaddr, timeoutMs);
            sock.close();

            return true;
        } catch (IOException e) { return false; }
    }


}
